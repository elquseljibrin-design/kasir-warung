// ==========================================================
// SERVICE WORKER - Kasir Warung
// Meng-cache "app shell" (HTML/CSS/JS/ikon/font) supaya aplikasi
// tetap bisa TERBUKA saat offline atau sinyal lemah.
//
// PENTING: transaksi, produk, laporan tetap butuh koneksi internet
// karena data live di Google Sheets lewat Apps Script. Service worker
// ini hanya membuat TAMPILAN aplikasi tetap bisa dibuka tanpa internet
// (misal untuk melihat struk terakhir yang sempat ter-cache), bukan
// membuat transaksi bisa jalan sepenuhnya offline.
//
// Naikkan angka di CACHE_NAME setiap kali index.html/manifest diubah,
// supaya pengguna otomatis dapat versi terbaru.
// ==========================================================

const CACHE_NAME = 'kasir-warung-v1';

const APP_SHELL = [
  './',
  './index.html',
  './manifest.json',
  './icons/icon-192.png',
  './icons/icon-512.png',
  './icons/apple-touch-icon.png'
];

// --- INSTALL: simpan app shell ke cache ---
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(APP_SHELL))
  );
  self.skipWaiting();
});

// --- ACTIVATE: bersihkan cache versi lama ---
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((names) =>
      Promise.all(
        names
          .filter((name) => name !== CACHE_NAME)
          .map((name) => caches.delete(name))
      )
    )
  );
  self.clients.claim();
});

// --- FETCH ---
self.addEventListener('fetch', (event) => {
  const url = new URL(event.request.url);

  // Jangan pernah cache/intercept panggilan ke backend Apps Script atau
  // request non-GET (checkout, saveProduk, dll HARUS selalu ke jaringan).
  if (event.request.method !== 'GET' || url.origin.includes('script.google.com')) {
    return; // biarkan lewat apa adanya (network langsung)
  }

  // App shell & aset sendiri (index.html, manifest, ikon): cache-first,
  // lalu update cache di belakang layar (stale-while-revalidate).
  if (url.origin === self.location.origin) {
    event.respondWith(
      caches.match(event.request).then((cached) => {
        const fetchPromise = fetch(event.request)
          .then((networkRes) => {
            caches.open(CACHE_NAME).then((cache) => cache.put(event.request, networkRes.clone()));
            return networkRes;
          })
          .catch(() => cached); // offline: pakai cache kalau fetch gagal
        return cached || fetchPromise;
      })
    );
    return;
  }

  // Aset pihak ketiga (Google Fonts, library html5-qrcode dari CDN):
  // cache-first supaya tetap tampil rapi walau offline setelah kunjungan pertama.
  event.respondWith(
    caches.match(event.request).then((cached) => {
      if (cached) return cached;
      return fetch(event.request).then((networkRes) => {
        caches.open(CACHE_NAME).then((cache) => cache.put(event.request, networkRes.clone()));
        return networkRes;
      }).catch(() => cached);
    })
  );
});
